<form id="form1" name="form1" method="post" action="perfil.php">
<label for="Nome">Nome</label><input type="text" name="Nome" id="Nome" />
<br class="clear" /> 
<label for="Distrito">Distrito</label><input type="text" name="Distrito" id="Distrito" />
<br class="clear" /> 
<label for="Data de Nascimento">Data de Nascimento</label><input type="text" name="Data de Nascimento" id="Data de Nascimento" />
<br class="clear" /> 
<label for="Estado Civil">Estado Civil</label><select name="Estado Civil" id="Estado Civil">
<option value="Sol.">Sol.</option>
<option value="Cas.">Cas.</option>
<option value="Div.">Div.</option>
<option value="Viu.">Viu.</option>
</select>
<br class="clear" /> 
<label for="Habilitações">Habilitações</label><input type="text" name="Habilitações" id="Habilitações" />
<br class="clear" /> 
<label for="foto">Foto</label><input type="file" name="foto" id="foto" />
<br class="clear" /> 
<label for="Descrição">Descrição</label><input type="text" name="Descrição" id="Descrição" />
<br class="clear" /> 
<label for="Procura">Procura</label><select name="Procura" id="Procura">
<option value="H">H</option>
<option value="M">M</option>
</select>
<br class="clear" /> 
<label for="Altura">Altura</label><input type="text" name="Altura" id="Altura" />
<br class="clear" /> 
<label for="Peso">Peso</label><input type="text" name="Peso" id="Peso" />
<br class="clear" /> 
</form>